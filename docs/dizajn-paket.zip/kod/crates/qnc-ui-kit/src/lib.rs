use eframe::egui::{self, Button, Color32, CornerRadius, RichText, Stroke, Vec2};

mod chrome_button;
mod option_columns;
mod raster;
mod text_field;
mod two_way_switch;
pub use chrome_button::{chrome_button, fill_block, on_dark, check_box, framed_button, look_button, press_feedback, sized_button, small_button, strong_button, ButtonLook, ChromeButtonStyle, PRESS_FEEDBACK_KEY};
pub use option_columns::*;
pub use raster::{paint_rgba_image, paint_rgba_image_filled};
pub use raster::paint_stream_frame;
pub use two_way_switch::show_two_way_switch;
pub use text_field::{row_field, search_field, text_area, text_field};

/// The thin frame of what the keyboard is on (a panel, a button, a tab), the same in every
/// form (user 2026-10-20: three pieces drew their own copy).
pub fn paint_focus(ui: &eframe::egui::Ui, rect: eframe::egui::Rect, focused: bool, color: eframe::egui::Color32) {
    if focused {
        // Thin and discreet (user 2026-10-24).
        let stroke = eframe::egui::Stroke::new(1.0, color.gamma_multiply(0.7));
        ui.painter().rect_stroke(rect, 0.0, stroke, eframe::egui::StrokeKind::Inside);
    }
}

pub const STANDARD_ACTION_BUTTON_WIDTH: f32 = 96.0;
pub const STANDARD_ACTION_BUTTON_GAP: f32 = 8.0;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FormActionBarStyle {
    pub text: Color32,
    pub primary_text: Color32,
    pub primary_fill: Color32,
    pub border: Color32,
    pub font_size: f32,
    pub height: f32,
    pub button_width: f32,
    pub gap: f32,
    pub right_margin: f32,
}

impl FormActionBarStyle {
    pub fn new(
        text: Color32,
        primary_fill: Color32,
        border: Color32,
        font_size: f32,
        height: f32,
    ) -> Self {
        // On the dark desktop the main button is never light (`on_dark`).
        let (primary_fill, primary_text, _) = on_dark(primary_fill, Color32::WHITE);
        Self {
            text,
            primary_text,
            primary_fill,
            border,
            font_size,
            height,
            button_width: STANDARD_ACTION_BUTTON_WIDTH,
            gap: STANDARD_ACTION_BUTTON_GAP,
            right_margin: STANDARD_ACTION_BUTTON_GAP,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct FormActionBarResponse {
    pub confirm_clicked: bool,
    pub cancel_clicked: bool,
    /// Where the two buttons are drawn (a form may frame the one the keyboard is on).
    pub confirm_rect: Option<egui::Rect>,
    pub cancel_rect: Option<egui::Rect>,
}

pub fn show_form_action_bar(
    ui: &mut egui::Ui,
    style: &FormActionBarStyle,
    confirm_label: &str,
    confirm_enabled: bool,
    cancel_label: &str,
) -> FormActionBarResponse {
    let mut response = FormActionBarResponse::default();
    ui.allocate_ui_with_layout(
        Vec2::new(ui.available_width(), style.height),
        egui::Layout::right_to_left(egui::Align::Center),
        |ui| {
            ui.spacing_mut().item_spacing.x = style.gap;
            ui.add_space(style.right_margin);
            let confirm = primary_button(ui, style, confirm_label, confirm_enabled);
            (response.confirm_clicked, response.confirm_rect) = (confirm.clicked(), Some(confirm.rect));
            let cancel = action_button(ui, style, cancel_label);
            (response.cancel_clicked, response.cancel_rect) = (cancel.clicked(), Some(cancel.rect));
        },
    );
    response
}

fn primary_button(
    ui: &mut egui::Ui,
    style: &FormActionBarStyle,
    label: &str,
    enabled: bool,
) -> egui::Response {
    ui.add_enabled(
        enabled,
        Button::new(
            RichText::new(label)
                .color(style.primary_text)
                .strong()
                .size(style.font_size),
        )
        .fill(style.primary_fill)
        .stroke(Stroke::new(0.0, Color32::TRANSPARENT))
        .corner_radius(CornerRadius::same(0))
        .min_size(action_button_size(style)),
    )
}

fn action_button(ui: &mut egui::Ui, style: &FormActionBarStyle, label: &str) -> egui::Response {
    ui.add(
        Button::new(RichText::new(label).color(style.text).size(style.font_size))
            .fill(Color32::TRANSPARENT)
            .stroke(Stroke::new(1.0, style.border))
            .corner_radius(CornerRadius::same(0))
            .min_size(action_button_size(style)),
    )
}

fn action_button_size(style: &FormActionBarStyle) -> Vec2 {
    Vec2::new(style.button_width, style.height)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn standard_action_buttons_have_equal_width() {
        let style = FormActionBarStyle::new(
            Color32::WHITE,
            Color32::from_rgb(1, 2, 3),
            Color32::from_rgb(4, 5, 6),
            14.0,
            30.0,
        );

        assert_eq!(style.button_width, STANDARD_ACTION_BUTTON_WIDTH);
        assert_eq!(style.gap, STANDARD_ACTION_BUTTON_GAP);
    }

}
